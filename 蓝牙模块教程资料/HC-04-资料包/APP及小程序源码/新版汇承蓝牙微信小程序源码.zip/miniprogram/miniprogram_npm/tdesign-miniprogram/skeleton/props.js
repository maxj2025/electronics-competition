const props = {
    animation: {
        type: String,
        value: 'none',
    },
    delay: {
        type: Number,
        value: 0,
    },
    externalClasses: {
        type: Array,
    },
    loading: {
        type: Boolean,
        value: true,
    },
    rowCol: {
        type: Array,
    },
    theme: {
        type: String,
        value: 'text',
    },
};
export default props;
