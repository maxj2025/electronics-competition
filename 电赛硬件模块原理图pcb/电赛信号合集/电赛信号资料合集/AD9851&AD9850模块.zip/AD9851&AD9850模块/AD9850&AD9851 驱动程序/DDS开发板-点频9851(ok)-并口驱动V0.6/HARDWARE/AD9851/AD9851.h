#ifndef __AD9851_H
#define __AD9851_H	 
#include "sys.h"

#define AD9851_w_clk    PAout(4)  //
#define AD9851_fq_up    PAout(3)  //
#define AD9851_rest     PAout(6)  //
#define AD9851_bit_data PCout(7)  //
#define AD9851_DataBus	GPIOC->BSRR
#define D0   		PCout(0)
#define D1   		PCout(1)
#define D2   		PCout(2)


void AD9851_reset(void);
void AD9851_wr_parrel(u8 w0,double frequence);
void AD9851_IO_Init(void);
void AD9851_Setfq(double fq);
void AD9851_Init(void);

#endif

