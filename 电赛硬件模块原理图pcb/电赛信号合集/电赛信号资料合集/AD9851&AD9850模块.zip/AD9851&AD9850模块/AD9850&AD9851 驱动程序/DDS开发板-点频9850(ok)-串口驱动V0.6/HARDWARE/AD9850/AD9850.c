#include "AD9850.h" 

u8 AD9850_FD=0x00; //����Ƶ,AD9850��֧�ֱ�Ƶ��AD9851֧�ֱ�Ƶ

//***************************************************//
//              AD9850��λ(����ģʽ)                 //
//---------------------------------------------------//
void AD9850_reset_serial()
{
	AD9850_w_clk=0;
	AD9850_fq_up=0;
	//rest�ź�
	AD9850_rest=0;
	AD9850_rest=1;
	AD9850_rest=0;
	//w_clk�ź�
	AD9850_w_clk=0;
	AD9850_w_clk=1;
	AD9850_w_clk=0;
	//fq_up�ź�
	AD9850_fq_up=0;
	AD9850_fq_up=1;
	AD9850_fq_up=0;
}

//***************************************************//
//          ��AD9850��д����������(����)             //
//---------------------------------------------------//
void AD9850_wr_serial(u8 w0,double frequence)
{
	unsigned char i,w;
	long int y;
	double x;
	//����Ƶ�ʵ�HEXֵ
	x=4294967295/125;//�ʺ�125M����
	
	frequence=frequence/1000000;
	frequence=frequence*x;
	y=frequence;
	//дw4����
	w=(y>>=0);
	for(i=0;i<8;i++)
	{
		AD9850_bit_data=(w>>i)&0x01;
		AD9850_w_clk=1;
		AD9850_w_clk=0;
	}
	//дw3����
	w=(y>>8);
	for(i=0;i<8;i++)
	{
		AD9850_bit_data=(w>>i)&0x01;
		AD9850_w_clk=1;
		AD9850_w_clk=0;
	}
	//дw2����
	w=(y>>16);
	for(i=0;i<8;i++)
	{
		AD9850_bit_data=(w>>i)&0x01;
		AD9850_w_clk=1;
		AD9850_w_clk=0;
	}
	//дw1����
	w=(y>>24);
	for(i=0;i<8;i++)
	{
		AD9850_bit_data=(w>>i)&0x01;
		AD9850_w_clk=1;
		AD9850_w_clk=0;
	}
	//дw0����
	w=w0;   
	for(i=0;i<8;i++)
	{
		AD9850_bit_data=(w>>i)&0x01;
		AD9850_w_clk=1;
		AD9850_w_clk=0;
	}
	//����ʼ��
	AD9850_fq_up=1;
	AD9850_fq_up=0;
}
void AD9850_IO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure ; 

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOC, ENABLE);	 //ʹ��PB,PE�˿�ʱ��

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0| GPIO_Pin_1| GPIO_Pin_2| GPIO_Pin_3| GPIO_Pin_4| GPIO_Pin_5| GPIO_Pin_6| GPIO_Pin_7 ; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;	
	GPIO_Init(GPIOC ,&GPIO_InitStructure) ;

	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_3|GPIO_Pin_4| GPIO_Pin_6; 
	GPIO_Init(GPIOA ,&GPIO_InitStructure) ;
}
//Ƶ�����
void AD9850_Setfq(double fq)
{
	AD9850_wr_serial(AD9850_FD,fq);
}


void AD9850_Init(void)
{
	AD9850_IO_Init();
	D2=0;D1=1;D0=1; //���ô���ģʽD2��D0��̶���ƽ011�����оƬ�����ֲ�
	AD9850_reset_serial();
}








