#ifndef __AD9850_H
#define __AD9850_H	 
#include "sys.h"

#define AD9850_w_clk    PAout(4)  //
#define AD9850_fq_up    PAout(3)  //
#define AD9850_rest     PAout(6)  //
#define AD9850_bit_data PCout(7)  //
#define AD9850_DataBus	GPIOC->BSRR
#define D0   		PCout(0)
#define D1   		PCout(1)
#define D2   		PCout(2)


void AD9850_reset(void);
void AD9850_wr_parrel(u8 w0,double frequence);
void AD9850_IO_Init(void);
void AD9850_Setfq(double fq);
void AD9850_Init(void);

#endif

