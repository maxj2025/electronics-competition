/**********************************************************
                       ��������
										 
���ܣ�stm32f103rct6���ƣ�MCP41xxд��ֵ(0-255  ->  0-R)
			��������0-255���������ֵ�ɸ���R�ܼ���
			��ʾ��12864cog
�ӿڣ����ƽӿ������MCP41xx.h  �����ӿ������key.h
ʱ�䣺2015/11/10
�汾��1.0
���ߣ���������
�����������м���л�����

������������뵽�Ա��꣬�������ӽ߳�Ϊ������ ^_^
���̣�kvdz.taobao.com

**********************************************************/

#include "task_manage.h"
#include "delay.h"
#include "key.h"
#include "MCP41xx.h"

#define OUT_KEY  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2)//��ȡ����0
#define FLASH_SAVE_ADDR  0x0801F000  				//����FLASH �����ַ(����Ϊż��)

u8 Firt_In = 1;
u8 Task_Index = 0;
u8 _return=0;
u8 Task_Delay(u32 delay_time, u8* delay_ID)
{
	static u8 Time_Get = 0;
	static u32 Time_Triger;
    if(Time_Get == 0)
    {
      Time_Triger = SysTimer + delay_time;
      Time_Get = 1;
    }
    if(SysTimer >= Time_Triger)
    { 
      Time_Get = 0;
			*delay_ID = 1;		//	���������ѱ�ִ��һ��
			return 1;
    }
		return 0;
}

//u8 TaskOneToIdel(void)
//{
//	static u8 delay_ID0 = 0;
//	static u8 delay_ID1 = 0;
//	static u8 delay_ID2 = 0;
//	static u8 delay_ID3 = 0;
//	u8 delay_arrive0 = 0;
//	u8 delay_arrive1 = 0;
//	u8 delay_arrive2 = 0;
//	u8 delay_arrive3 = 0;
//	
//	delay_arrive0 = Task_Delay(100, &delay_ID0);
//	delay_arrive1 = Task_Delay(100, &delay_ID1);
//	delay_arrive2 = Task_Delay(100, &delay_ID2);
//	delay_arrive3 = Task_Delay(100, &delay_ID3);
//	if((delay_arrive0 == 0) && (delay_ID0 == 0))
//		return 0;
//	else if((delay_arrive0) && (delay_ID0))
//	{
//			//ִ�б���ʱ�����
//	}
//		
//	
//	
//	if(delay_ID0&&delay_ID1&&delay_ID2&&delay_ID3)
//	{
//		delay_ID0 = 0;
//		delay_ID1 = 0;
//		delay_ID2 = 0;
//		delay_ID3 = 0;
//	}
//}

u8 TaskCycleDelay(u32 delay_time, u8* Last_delay_ID, u8* Self_delay_ID)
{
	static u8 Time_Get = 0;
	static u32 Time_Triger;
	
	if(!(*Last_delay_ID))
		return 0;
	if(Time_Get == 0)
	{
		Time_Triger = SysTimer + delay_time;
		Time_Get = 1;
	}
	if(SysTimer >= Time_Triger)
	{ 
		Time_Get = 0;
		*Last_delay_ID = 0;
		*Self_delay_ID = 1;		//	���������ѱ�ִ��һ��
		return 1;
	}
	return 0;
}
void welcome_KW(void)
{
	u8 delay_ID[11] = {0,0,0,0,0,0,0,0,0,0};
	u8 delay_ID_Welcome[3] = {0,0,0};
	u16 Wel_time0 = 50,Wel_time1 = 100;
	delay_ID[10] = 1;
	delay_ID_Welcome[2] = 1;
	LCD_Show_CEStr(0,6,"ADF4351");
	LCD_Show_CEStr(56,6,"��ʼ��");
	while(1)
	{
	if(TaskCycleDelay(Wel_time0, &delay_ID[10], &delay_ID[0]))
		LCD_Show_CEStr(32,0,"��");
	if(TaskCycleDelay(Wel_time0, &delay_ID[0], &delay_ID[1]))
		LCD_Show_CEStr(48,0,"��");
	if(TaskCycleDelay(Wel_time0, &delay_ID[1], &delay_ID[2]))
		LCD_Show_CEStr(64,0,"��");
	if(TaskCycleDelay(Wel_time0, &delay_ID[2], &delay_ID[3]))
		LCD_Show_CEStr(80,0,"��");
	if(TaskCycleDelay(Wel_time0, &delay_ID[3], &delay_ID[4]))
		LCD_Show_CEStr(16,2,"��");
	if(TaskCycleDelay(Wel_time0, &delay_ID[4], &delay_ID[5]))
		LCD_Show_CEStr(32,2,"��");
	if(TaskCycleDelay(Wel_time0, &delay_ID[5], &delay_ID[6]))
		LCD_Show_CEStr(48,2,"Ϊ");
	if(TaskCycleDelay(Wel_time0, &delay_ID[6], &delay_ID[7]))
		LCD_Show_CEStr(64,2,"��");
	if(TaskCycleDelay(Wel_time0, &delay_ID[7], &delay_ID[8]))
		LCD_Show_CEStr(80,2,"��");
	if(TaskCycleDelay(Wel_time0, &delay_ID[8], &delay_ID[9]))
		LCD_Show_CEStr(96,2,"��");
	if(TaskCycleDelay(Wel_time0, &delay_ID[9], &delay_ID[0]))
		break;
	if(TaskCycleDelay(Wel_time1, &delay_ID_Welcome[2], &delay_ID_Welcome[0]))
		LCD_Show_CEStr(104,6,".  ");
	if(TaskCycleDelay(Wel_time1, &delay_ID_Welcome[0], &delay_ID_Welcome[1]))
		LCD_Show_CEStr(112,6,".");
	if(TaskCycleDelay(Wel_time1, &delay_ID_Welcome[1], &delay_ID_Welcome[2]))
		LCD_Show_CEStr(120,6,".");
		LCD_Refresh_Gram();
	}
}

void Copybuf2dis(u8 *source, u8 dis[10], u8  dispoint)
{
	dis[0] = *source + 		 '0';
	dis[1] = *(source+1) + '0';
	dis[2] = *(source+2) + '0';
	dis[3] = 0;

	dis[dispoint] += 128;
}

void Copybuf2disbai(u8 *source, u8 dis[10])//�޹��
{
	dis[0] = *source + 		 '0';
	dis[1] = *(source+1) + '0';
	dis[2] = *(source+2) + '0';
	dis[3] = 0;

}

void Set_PointFre(u32 Key_Value, u8* Task_ID)
{
	static u8 P_Index1 = 0,P_Index2 = 0, R_Index = 0;
	static u16 Fre1 = 127,Fre2 = 127;
	
	u8 fre_buf1[4],fre_buf2[4];
	u8 display[15];


	if(Firt_In) 
	{
		Key_Value = K_2_S;
		LCD_Show_CEStr(0,0,"     ������     ");
		LCD_Show_CEStr(0,2,"  ����1  ����2  ");
		//LCD_Show_CEStr(0,4,"    ��������    ");
		//LCD_Show_CEStr(0,6,"kvdz.taobao.com");
		Firt_In = 0;
		_return=1;		
	}
	fre_buf1[0] = Fre1%1000/100;
	fre_buf1[1] = Fre1%100/10;
	fre_buf1[2] = Fre1%10;
	fre_buf2[0] = Fre2%1000/100;
	fre_buf2[1] = Fre2%100/10;
	fre_buf2[2] = Fre2%10;
	
	switch(Key_Value)
	{
		case K_4_S: if(R_Index==0)
									fre_buf1[P_Index1]++;
								else if(R_Index==1)
									fre_buf2[P_Index2]++;break;
		case K_4_L: if(R_Index==0)
									fre_buf1[P_Index1]++;
								else if(R_Index==1)
									fre_buf2[P_Index2]++;break;	
								
		case K_5_L: if(R_Index==0)P_Index1++;
								else if(R_Index==1)P_Index2++;
								break;
		case K_5_S: if(R_Index==0)P_Index1++;
								else if(R_Index==1)P_Index2++;
								break;
		case K_1_L:if(R_Index==0)P_Index1--;
								else if(R_Index==1)P_Index2--;
								break;
		case K_1_S: if(R_Index==0)P_Index1--;
								else if(R_Index==1)P_Index2--;
								break;
								
		case K_3_S:  if(R_Index==0)
									fre_buf1[P_Index1]--;
								else if(R_Index==1)
									fre_buf2[P_Index2]--;break;	
		case K_3_L:  if(R_Index==0)
									fre_buf1[P_Index1]--;
								else if(R_Index==1)
									fre_buf2[P_Index2]--;break;	
		case K_2_L: R_Index^=1;break;
	}
	
	P_Index1 %= 3;
	P_Index2 %= 3;
	if(R_Index==0)
	{
		if(fre_buf1[P_Index1] == 255) fre_buf1[P_Index1] = 9;
		if(fre_buf1[P_Index1] ==  10) fre_buf1[P_Index1] = 0;
	}
	else if(R_Index==1)
	{
		if(fre_buf2[P_Index2] == 255) fre_buf2[P_Index2] = 9;
		if(fre_buf2[P_Index2] ==  10) fre_buf2[P_Index2] = 0;
	}
	
	if(Key_Value != K_NO)
	{
		Fre1 = fre_buf1[0]*100 + fre_buf1[1]*10 + fre_buf1[2];
		Fre2 = fre_buf2[0]*100 + fre_buf2[1]*10 + fre_buf2[2];
		if(Fre1>255) Fre1=255;
		if(Fre2>255) Fre2=255;
		fre_buf1[0] = Fre1%1000/100;
		fre_buf1[1] = Fre1%100/10;
		fre_buf1[2] = Fre1%10;
		
		fre_buf2[0] = Fre2%1000/100;
		fre_buf2[1] = Fre2%100/10;
		fre_buf2[2] = Fre2%10;
		if(R_Index==0)
		{
			Copybuf2disbai(fre_buf2, display);
			OLED_ShowString(90-4*3, 4, display);
			Copybuf2dis(fre_buf1, display, P_Index1);
			OLED_ShowString(35-4*3, 4, display);
			//�������õ���1
			MCP41xx_1writedata((u8)Fre1);
		}
		else if(R_Index==1)
		{
			Copybuf2disbai(fre_buf1, display);
			OLED_ShowString(35-4*3, 4, display);
			Copybuf2dis(fre_buf2, display, P_Index2);
			OLED_ShowString(90-4*3, 4, display);
			//�������õ���2
			MCP41xx_2writedata((u8)Fre2);
		}
		
		_return=1;
	}
}
