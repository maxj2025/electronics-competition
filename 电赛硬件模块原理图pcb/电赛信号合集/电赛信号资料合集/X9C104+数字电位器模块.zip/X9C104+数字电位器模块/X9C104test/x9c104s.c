#include<reg52.h>
#include<intrins.h>
#define uchar unsigned char

sbit inc=P2^0;
sbit ud=P2^1;
sbit cs=P2^2;

sbit led=P2^4;

sbit up=P0^7;
sbit down=P0^6;


void delay(int time)
{
	int i,j;
	for(i=0;i<time;i++)
		for(j=0;j<10;j++)
		_nop_();
}

void x9c104s_set(uchar number)
{
	uchar i;
	inc=1;
	delay(10);
 	delay(10);
	cs=0;
	delay(10); 
	delay(10);
	ud=0; //����Ϊ��
	delay(10); 
	delay(10);

	for(i=0;i<100;i++) /*��Ϊ��оƬΪ100��ͷ ����������*/
	{
		inc=1;	led=1;
		delay(10); 
		inc=0;	led=0;
		delay(10); 

	}
	ud=1; //������
	delay(10); 
	delay(10); 



	for(i=0;i<number;i++) //�趨��ʼֵ
	{
		inc=1; led=1;
		delay(10); //�½�����Ч
		inc=0; led=0;
		delay(10);
	}


	inc=1; //����Ϊ�����趨ֵ
	delay(10);
	delay(10);
	cs=1;
	delay(2000);
	delay(10);
	ud=1;
	delay(10); 
	delay(10);
	inc=1;
}


void x9c104s_inc(uchar number)
{
	uchar i;
	inc=1;
	delay(10);
	delay(10);
	cs=0;
	delay(10); 
	delay(10);
	ud=1;
	delay(10); 
	delay(10);

	for(i=0;i<number;i++) //�趨��ֵ
	{
		inc=1; led=1;
		delay(10); 

		inc=0; led=0;
		delay(10000000);

	} 

	inc=1; //����Ϊ�����趨ֵ
	delay(10);
	delay(10);
	cs=1;
	delay(2000);
	delay(10);
	ud=1;
	delay(10);
	delay(10);
	inc=1;
} 


void x9c104s_dec(uchar number)
{
	uchar i;
	inc=1; //ѡ�и�оƬ
	delay(10);
	delay(10);
	cs=0;
	delay(10);
	delay(10);
	ud=0; //����Ϊ��С
	delay(10);
	delay(10);
	for(i=0;i<number;i++)
	{
		inc=1;	led=1;
		delay(10);

		inc=0;	led=0;
		delay(10000000);

	}
	inc=1; //�����趨ֵ
	delay(10);
	delay(10);
	cs=1;
	delay(2000);

	ud=1;
	delay(10);
	delay(10);
	inc=1;
} 

void main()
{
   //int N=0;
	up=0;
	down=0;
	x9c104s_set(30);

	while(1)
	{
		if(up == 1)
		{	
			delay(100000);
			if(up == 1)
				x9c104s_inc(10);
		}


		if(down == 1)
		{
		   delay(100000);
			if(down == 1)	
				x9c104s_dec(10);	
		}


	} 

}